import { translations, type Language } from './translations';

export type DeviceKind = 'mobile' | 'tablet' | 'desktop';

export type ScreenLayoutVariant =
  | 'mobile-hero'
  | 'mobile-grid'
  | 'mobile-story'
  | 'mobile-lightbox'
  | 'tablet-split'
  | 'tablet-masonry'
  | 'tablet-exhibition'
  | 'desktop-hero'
  | 'desktop-bento'
  | 'desktop-plate';

export interface ShowcaseSlide {
  id: string;
  device: DeviceKind;
  variant: ScreenLayoutVariant;
  viewportLabel: string;
  primaryImage: string;
  secondaryImages?: string[];
  exif: string;
  weight: string;
  copy: Record<
    Language,
    {
      title: string;
      caption: string;
      alt: string;
      screenTitle: string;
      screenKicker: string;
      screenNote: string;
    }
  >;
}

export function getMobileSlides(language: Language): ShowcaseSlide[] {
  const routes = translations[language].images.mobile;
  return [
    {
      id: 'mob-01',
      device: 'mobile',
      variant: 'mobile-hero',
      viewportLabel: '390 × 844 px',
      primaryImage: routes.mob01,
      exif: '28mm · f/4.0 · ISO 100',
      weight: '38 KB WebP',
      copy: {
        en: {
          title: 'Vertical Editorial Landing',
          caption: 'Full-height architectural lead frame with single-thumb header navigation.',
          alt: 'Mobile website view displaying a monochrome concrete spiral staircase photograph and minimalist gallery header',
          screenTitle: 'Ascent Studies',
          screenKicker: 'Series 01 · Geneva',
          screenNote: '14 architectural plates',
        },
        fr: {
          title: 'Accueil Éditorial Vertical',
          caption: 'Planche architecturale plein cadre avec navigation supérieure épurée.',
          alt: 'Vue mobile du site présentant une photographie monochrome d’escalier en spirale et un en-tête minimaliste',
          screenTitle: 'Études d’Ascension',
          screenKicker: 'Série 01 · Genève',
          screenNote: '14 planches architecturales',
        },
      },
    },
    {
      id: 'mob-02',
      device: 'mobile',
      variant: 'mobile-grid',
      viewportLabel: '390 × 844 px',
      primaryImage: routes.mob02Primary,
      secondaryImages: [routes.mob02Secondary],
      exif: '50mm · f/2.8 · ISO 200',
      weight: '44 KB WebP',
      copy: {
        en: {
          title: 'Dual-Frame Photo Index',
          caption: 'Stacked responsive cards with unboxed typographic metadata and instant tap zoom.',
          alt: 'Mobile gallery archive screen showing botanical shadow and stoneware ceramic still life photographs',
          screenTitle: 'Quiet Objects',
          screenKicker: 'Archive Index',
          screenNote: 'Tap any plate to inspect',
        },
        fr: {
          title: 'Index Photographique Empilé',
          caption: 'Cartes réactives superposées avec métadonnées typographiques sans surcharge.',
          alt: 'Écran mobile d’archive montrant des photographies d’ombre botanique et de céramiques en grès',
          screenTitle: 'Objets Silencieux',
          screenKicker: 'Index d’Archive',
          screenNote: 'Toucher pour agrandir',
        },
      },
    },
    {
      id: 'mob-03',
      device: 'mobile',
      variant: 'mobile-story',
      viewportLabel: '390 × 844 px',
      primaryImage: routes.mob03,
      exif: '35mm · f/5.6 · 1/125s',
      weight: '41 KB WebP',
      copy: {
        en: {
          title: 'Monograph Story Plate',
          caption: 'Clean darkroom metadata strip positioned below a calibrated 4:3 horizon frame.',
          alt: 'Mobile monograph reader page featuring a Nordic basalt coast photograph at dusk',
          screenTitle: 'North Basin',
          screenKicker: 'Field Notes · 2026',
          screenNote: 'Medium format 6×7 scan',
        },
        fr: {
          title: 'Planche Monographique',
          caption: 'Bandeau technique discret placé sous un cadrage littoral calibré en 4:3.',
          alt: 'Page mobile monographique présentant un paysage côtier nordique au crépuscule',
          screenTitle: 'Bassin Nord',
          screenKicker: 'Notes de Terrain · 2026',
          screenNote: 'Numérisation moyen format 6×7',
        },
      },
    },
    {
      id: 'mob-04',
      device: 'mobile',
      variant: 'mobile-lightbox',
      viewportLabel: '390 × 844 px',
      primaryImage: routes.mob04,
      exif: '24mm · f/8.0 · ISO 64',
      weight: '49 KB WebP',
      copy: {
        en: {
          title: 'Darkroom Mobile Lightbox',
          caption: 'Low-glare dark inspection canvas with accessible swipe and close targets.',
          alt: 'Mobile fullscreen dark lightbox displaying a concrete museum pavilion reflected in water',
          screenTitle: 'Pavilion West',
          screenKicker: 'Plate 04 / 12',
          screenNote: 'Swipe or press ESC',
        },
        fr: {
          title: 'Visionneuse Mobile Sombre',
          caption: 'Fond sombre anti-reflet avec gestes tactiles et bouton de fermeture accessible.',
          alt: 'Visionneuse mobile sombre plein écran affichant un pavillon en béton reflété dans l’eau',
          screenTitle: 'Pavillon Ouest',
          screenKicker: 'Planche 04 / 12',
          screenNote: 'Glisser ou Échap',
        },
      },
    },
  ];
}

export function getTabletSlides(language: Language): ShowcaseSlide[] {
  const routes = translations[language].images.tablet;
  return [
    {
      id: 'tab-01',
      device: 'tablet',
      variant: 'tablet-split',
      viewportLabel: '1024 × 768 px',
      primaryImage: routes.tab01,
      exif: '35mm · f/5.6 · ISO 100',
      weight: '62 KB WebP',
      copy: {
        en: {
          title: 'Split Editorial Monograph',
          caption: 'Left-hand series directory paired with a generous 4:3 exhibition photograph.',
          alt: 'Tablet split-screen layout displaying series navigation on the left and a misty Nordic seascape on the right',
          screenTitle: 'Tidal Silence',
          screenKicker: 'Selected Works · 2025–2026',
          screenNote: 'Nordic Coastline Exhibition',
        },
        fr: {
          title: 'Monographie en Écran Scindé',
          caption: 'Sommaire des séries à gauche associé à un tirage d’exposition en 4:3.',
          alt: 'Mise en page tablette divisée montrant l’index des séries à gauche et un paysage côtier brumeux à droite',
          screenTitle: 'Silence des Marées',
          screenKicker: 'Œuvres Choisies · 2025–2026',
          screenNote: 'Exposition Littoral Nordique',
        },
      },
    },
    {
      id: 'tab-02',
      device: 'tablet',
      variant: 'tablet-masonry',
      viewportLabel: '1024 × 768 px',
      primaryImage: routes.tab02Primary,
      secondaryImages: [routes.tab02SecondaryA, routes.tab02SecondaryB],
      exif: '50mm · f/2.0 · ISO 160',
      weight: '71 KB WebP',
      copy: {
        en: {
          title: 'Balanced Two-Column Grid',
          caption: 'Rhythmic portrait and still-life pairing preserving generous breathing room.',
          alt: 'Tablet two-column photo gallery grid featuring stoneware ceramics, olive shadow study, and spiral architecture',
          screenTitle: 'Material Studies',
          screenKicker: '3 Curated Series',
          screenNote: 'Stoneware · Light · Concrete',
        },
        fr: {
          title: 'Grille Équilibrée Deux Colonnes',
          caption: 'Association rythmée de natures mortes et de portraits avec de larges marges.',
          alt: 'Grille galerie tablette à deux colonnes montrant des céramiques, une étude d’ombre et un escalier',
          screenTitle: 'Études de Matière',
          screenKicker: '3 Séries Choisies',
          screenNote: 'Grès · Lumière · Béton',
        },
      },
    },
    {
      id: 'tab-03',
      device: 'tablet',
      variant: 'tablet-exhibition',
      viewportLabel: '1024 × 768 px',
      primaryImage: routes.tab03,
      exif: '28mm · f/4.0 · ISO 400',
      weight: '68 KB WebP',
      copy: {
        en: {
          title: 'Gallery Room Overview',
          caption: 'Wide museum perspective paired with bilingual curatorial statement and print specs.',
          alt: 'Tablet exhibition view showing a bright contemporary photography gallery interior with framed prints',
          screenTitle: 'Winter Salon',
          screenKicker: 'Exhibition Catalogue',
          screenNote: 'Archival baryta prints',
        },
        fr: {
          title: 'Vue d’Espace d’Exposition',
          caption: 'Perspective muséale associée à un texte curatorial bilingue et aux formats de tirage.',
          alt: 'Aperçu tablette présentant l’intérieur d’une galerie contemporaine avec des tirages encadrés',
          screenTitle: 'Salon d’Hiver',
          screenKicker: 'Catalogue d’Exposition',
          screenNote: 'Tirages barytés d’archive',
        },
      },
    },
  ];
}

export function getDesktopSlides(language: Language): ShowcaseSlide[] {
  const routes = translations[language].images.desktop;
  return [
    {
      id: 'desk-01',
      device: 'desktop',
      variant: 'desktop-hero',
      viewportLabel: '1440 × 900 px',
      primaryImage: routes.desk01,
      exif: '24mm · f/8.0 · ISO 64',
      weight: '86 KB WebP',
      copy: {
        en: {
          title: 'Widescreen Hero & Top Bar',
          caption: 'Asymmetric 1440px hero canvas with 3-zone header and crisp architectural anchor.',
          alt: 'Desktop browser view showing the minimalist photo gallery homepage with concrete pavilion photography',
          screenTitle: 'Form & Reflection',
          screenKicker: 'Monograph Edition',
          screenNote: 'Concrete Pavilion · Marfa',
        },
        fr: {
          title: 'Accueil Grand Écran 1440px',
          caption: 'Toile d’ouverture asymétrique avec barre supérieure à 3 zones et ancrage architectural.',
          alt: 'Aperçu ordinateur montrant la page d’accueil minimaliste avec photographie d’un pavillon en béton',
          screenTitle: 'Forme & Reflet',
          screenKicker: 'Édition Monographie',
          screenNote: 'Pavillon Béton · Marfa',
        },
      },
    },
    {
      id: 'desk-02',
      device: 'desktop',
      variant: 'desktop-bento',
      viewportLabel: '1440 × 900 px',
      primaryImage: routes.desk02Primary,
      secondaryImages: [routes.desk02SecondaryA, routes.desk02SecondaryB],
      exif: '28mm–50mm · Studio & Field',
      weight: '94 KB WebP',
      copy: {
        en: {
          title: 'Asymmetric Bento Portfolio',
          caption: 'Primary 2-column gallery feature beside vertical still-life and landscape plates.',
          alt: 'Desktop bento grid layout combining gallery interior, coastal seascape, and ceramic still-life photographs',
          screenTitle: 'Selected Archive',
          screenKicker: '2024–2026 Works',
          screenNote: 'Filterable by discipline',
        },
        fr: {
          title: 'Portfolio Bento Asymétrique',
          caption: 'Planche principale sur deux colonnes accompagnée de formats verticaux et paysages.',
          alt: 'Grille bento ordinateur réunissant vue de galerie, littoral nordique et natures mortes en céramique',
          screenTitle: 'Archive Choisie',
          screenKicker: 'Travaux 2024–2026',
          screenNote: 'Filtrage par discipline',
        },
      },
    },
    {
      id: 'desk-03',
      device: 'desktop',
      variant: 'desktop-plate',
      viewportLabel: '1440 × 900 px',
      primaryImage: routes.desk03Primary,
      secondaryImages: [routes.desk03Secondary],
      exif: '28mm · f/4.0 · Monochrome',
      weight: '79 KB WebP',
      copy: {
        en: {
          title: 'Diptych & EXIF Inspector',
          caption: 'Side-by-side vertical diptych presentation with calibrated tabular darkroom notes.',
          alt: 'Desktop diptych viewer showing spiral staircase and olive shadow photographs with technical metadata',
          screenTitle: 'Light & Geometry',
          screenKicker: 'Diptych Plate 08',
          screenNote: 'Full EXIF & print edition',
        },
        fr: {
          title: 'Diptyque & Inspecteur EXIF',
          caption: 'Présentation côte à côte en diptyque vertical avec notes techniques tabulaires.',
          alt: 'Visionneuse diptyque sur ordinateur montrant l’escalier en spirale et l’ombre d’olivier avec métadonnées',
          screenTitle: 'Lumière & Géométrie',
          screenKicker: 'Planche Diptyque 08',
          screenNote: 'Données EXIF & tirage',
        },
      },
    },
  ];
}
